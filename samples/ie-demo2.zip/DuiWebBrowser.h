#pragma once

#include <DuiActiveX.h>
#include <ExDisp.h>
#include <ExDispid.h>

namespace DuiEngine
{
	struct IWebEvent
	{
		virtual void BeforeNavigate2( IDispatch *pDisp,VARIANT *&url,VARIANT *&Flags,VARIANT *&TargetFrameName,VARIANT *&PostData,VARIANT *&Headers,VARIANT_BOOL *&Cancel )=0;
		virtual void NavigateError(IDispatch *pDisp,VARIANT * &url,VARIANT *&TargetFrameName,VARIANT *&StatusCode,VARIANT_BOOL *&Cancel)=0;
		virtual void NavigateComplete2(IDispatch *pDisp,VARIANT *&url)=0;
		virtual void ProgressChange(LONG nProgress, LONG nProgressMax)=0;
		virtual void CommandStateChange(long Command,VARIANT_BOOL Enable)=0;
	};

	class CWebEventDispatch : public IDispatch
	{
	public:
		CWebEventDispatch(IWebEvent *pEventHandler):m_pEventHandler(pEventHandler),m_cRef(1)
		{

		}
		
		// IUnknown
		STDMETHOD_(ULONG,AddRef)()
		{
			return ++m_cRef;
		}
		STDMETHOD_(ULONG,Release)()
		{
			return --m_cRef;
		}

		STDMETHOD(QueryInterface)(REFIID riid, LPVOID *ppvObject)
		{
			if(IsEqualGUID(riid,__uuidof(IUnknown)) || IsEqualGUID(riid,__uuidof(IDispatch)))
			{
				*ppvObject=this;
				AddRef();
				return S_OK;
			}
			return E_NOINTERFACE;
		}

		//IDispatch
		virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
			/* [out] */ __RPC__out UINT *pctinfo){ return E_NOTIMPL;}

		virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( 
			/* [in] */ UINT iTInfo,
			/* [in] */ LCID lcid,
			/* [out] */ __RPC__deref_out_opt ITypeInfo **ppTInfo){ return E_NOTIMPL;}



		virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
			/* [in] */ __RPC__in REFIID riid,
			/* [size_is][in] */ __RPC__in_ecount_full(cNames) LPOLESTR *rgszNames,
			/* [range][in] */ UINT cNames,
			/* [in] */ LCID lcid,
			/* [size_is][out] */ __RPC__out_ecount_full(cNames) DISPID *rgDispId){ return E_NOTIMPL;}


		virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
			/* [in] */ DISPID dispIdMember,
			/* [in] */ REFIID riid,
			/* [in] */ LCID lcid,
			/* [in] */ WORD wFlags,
			/* [out][in] */ DISPPARAMS *pDispParams,
			/* [out] */ VARIANT *pVarResult,
			/* [out] */ EXCEPINFO *pExcepInfo,
			/* [out] */ UINT *puArgErr);

	protected:
		IWebEvent *m_pEventHandler;
		ULONG m_cRef;
	};

	class CDuiWebBrowser :	public CDuiActiveX, public IWebEvent
	{
		DUIOBJ_DECLARE_CLASS_NAME(CDuiWebBrowser, "browser")
	public:
		CDuiWebBrowser(void);
		~CDuiWebBrowser(void);

		IWebBrowser2 * GetIEObject(){return m_pIE;}
	protected:

	protected:
		virtual void OnAxActivate(IUnknown *pUnknwn);
	protected:
		// DWebBrowserEvents2
		void BeforeNavigate2( IDispatch *pDisp,VARIANT *&url,VARIANT *&Flags,VARIANT *&TargetFrameName,VARIANT *&PostData,VARIANT *&Headers,VARIANT_BOOL *&Cancel );
		void NavigateError(IDispatch *pDisp,VARIANT * &url,VARIANT *&TargetFrameName,VARIANT *&StatusCode,VARIANT_BOOL *&Cancel);
		void NavigateComplete2(IDispatch *pDisp,VARIANT *&url);
		void ProgressChange(LONG nProgress, LONG nProgressMax);
		void CommandStateChange(long Command,VARIANT_BOOL Enable);

		HRESULT RegisterEventHandler(BOOL inAdvise );


		DUIWIN_DECLARE_ATTRIBUTES_BEGIN()
			DUIWIN_WSTRING_ATTRIBUTE("url",m_strUrl,FALSE)
		DUIWIN_DECLARE_ATTRIBUTES_END()

		CDuiStringW m_strUrl;
		DWORD	m_dwCookie;
		
		CWebEventDispatch	m_eventDispatch;
		CDuiComQIPtr<IWebBrowser2> m_pIE;
	};

}
