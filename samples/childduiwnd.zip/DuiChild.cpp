#include "StdAfx.h"
#include "DuiChild.h"

CDuiChild::CDuiChild(void):CDuiHostWnd(_T("IDR_DUI_CHILD_DIALOG"))
{
}

CDuiChild::~CDuiChild(void)
{
}
